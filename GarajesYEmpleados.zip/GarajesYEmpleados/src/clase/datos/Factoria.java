package clase.datos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

public class Factoria {

    // Patrón singleton
    private static Factoria myInstance;
    public static Factoria getInstance() {
        if (myInstance == null)
            myInstance = new Factoria();
        return myInstance;
    }

    // Listados
    private Hashtable<Integer, TipoVehiculo> tipos_vehiculo;
    private Hashtable<Integer, Vehiculo> vehiculos;
    private Hashtable<Integer, Empleado> empleados;
    private Hashtable<Integer, Garaje> garajes;
    private int tipos_vehiculo_index;
    private int vehiculos_index;
    private int garajes_index;
    private int empleados_index;

    private Factoria() {
        this.tipos_vehiculo = new Hashtable<>();
        this.vehiculos = new Hashtable<>();
        this.empleados = new Hashtable<>();
        this.garajes = new Hashtable<>();
        this.tipos_vehiculo_index = 1;
        this.vehiculos_index = 1;
        this.garajes_index = 1;
        this.empleados_index = 1;

        poblarDatosIniciales();
    }

    private void poblarDatosIniciales() {
        TipoVehiculo t1 = new TipoVehiculo(1,"Deportivo");
        addTipoVehiculo(t1);
        addTipoVehiculo(new TipoVehiculo(2,"Compacto"));
        addTipoVehiculo(new TipoVehiculo(3,"Familiar"));
        addTipoVehiculo(new TipoVehiculo(4,"Berlina"));
        addTipoVehiculo(new TipoVehiculo(5,"Monovolumen"));
        addTipoVehiculo(new TipoVehiculo(6,"Todo terreno"));
        Vehiculo v1 = new Vehiculo("1234 ABC","Toledo", "Seat", t1);
        Garaje g1 = new Garaje("Garaje Pepe","13 Rue del percebe", "955550055");
        Empleado e1 = new Empleado("Pepe Gotera");
        Empleado e2 = new Empleado("Otilio");
        addVehiculo(v1);
        addGaraje(g1);
        addEmpleado(e1);
        v1.setGaraje(g1);
        g1.getVehiculos().add(v1);
        g1.getEmpleados().add(e1);
        g1.getEmpleados().add(e2);
    }


    public TipoVehiculo getTipoVehiculo(int id) {
        return tipos_vehiculo.get(id);
    }

    public static boolean isParsable(String input){
        boolean parsable = true;
        try{
            Integer.parseInt(input);
        }catch(NumberFormatException e){
            parsable = false;
        }
        return parsable;
    }

    public Hashtable<Integer, TipoVehiculo> getTiposVehiculo() {
        return tipos_vehiculo;
    }

    public int addTipoVehiculo(TipoVehiculo tipo) {
        tipo.setId(tipos_vehiculo_index);
        tipos_vehiculo.put(tipos_vehiculo_index, tipo);
        return tipos_vehiculo_index++;
    }

    public Hashtable<Integer, Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public int addVehiculo(Vehiculo vehiculo) {
        vehiculo.setId(vehiculos_index);
        vehiculos.put(vehiculos_index, vehiculo);
        return vehiculos_index++;
    }

    public Hashtable<Integer, Empleado> getEmpleados() {
        return empleados;
    }

    public int addEmpleado(Empleado empleado) {
        empleado.setId(empleados_index);
        empleados.put(empleados_index, empleado);
        return empleados_index++;
    }

    public Hashtable<Integer, Garaje> getGarajes() {
        return garajes;
    }

    public int addGaraje(Garaje garaje) {
        garaje.setId(garajes_index);
        garajes.put(garajes_index, garaje);
        return garajes_index++;
    }
}