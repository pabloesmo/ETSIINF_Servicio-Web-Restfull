package clase.datos;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "tipo_vehiculo")
public class TipoVehiculo {

    private int id;
    private String nombre;

    @XmlAttribute(required=false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoVehiculo() {

    }

    public TipoVehiculo(int id, String nombre) {
        super();
        this.id = id;
        this.nombre = nombre;
    }
}