package clase.datos;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "garaje")
public class Garaje {
    private int id;
    private String nombre;
    private String direccion;
    private String telefono;
    private ArrayList<Vehiculo> vehiculos;
    private ArrayList<Empleado> empleados;

    public Garaje() {
        this.vehiculos = new ArrayList<Vehiculo>();
        this.empleados = new ArrayList<Empleado>();
    }

    @XmlAttribute(required=false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @XmlElementWrapper(name="vehiculos")
    @XmlElement(name="vehiculo") 
    //@XmlTransient
    public ArrayList<Vehiculo> getVehiculos() {
        return vehiculos;
    }

    public void setVehiculos(ArrayList<Vehiculo> vehiculos) {
        this.vehiculos = vehiculos;
    }

    @XmlElementWrapper(name="empleados")
    @XmlElement(name="empleado") 
    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    public Garaje(String nombre, String direccion, String telefono) {
        super();
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.vehiculos = new ArrayList<>();
        this.empleados = new ArrayList<>();
    }
}