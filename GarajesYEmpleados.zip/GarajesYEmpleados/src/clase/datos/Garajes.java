package clase.datos;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "garajes")
public class Garajes {
	private ArrayList<Link> garajes;

	public Garajes() {
		this.garajes = new ArrayList<Link>();
	}

	@XmlElement(name="garaje")
	public ArrayList<Link> getGarajes() {
		return garajes;
	}

	public void setGarajes(ArrayList<Link> garajes) {
		this.garajes = garajes;
	}
}
