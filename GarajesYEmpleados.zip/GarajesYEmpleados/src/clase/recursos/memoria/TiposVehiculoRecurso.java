package clase.recursos.memoria;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import clase.datos.Factoria;
import clase.datos.TipoVehiculo;

@Path("/tipos_vehiculo")
public class TiposVehiculoRecurso {

	@Context
	private UriInfo uriInfo;
	
	private Factoria factoria;
	
	public TiposVehiculoRecurso() {
		this.factoria = Factoria.getInstance();
	}
	
	// Listado automático de los tipos no puede hacerse en XML sin hacer una clase que
	// englobe a la lista al ser una colección proviniente de un HashTable.
	// En JSON sí puede generarse un array a partir de una colección
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTiposVehiculo() {
		return Response.status(Response.Status.OK).entity(factoria.getTiposVehiculo().values()).header("Content-Location", uriInfo.getAbsolutePath()).build();
	}
	
	@GET
	@Path("{tipo_vehiculo_id}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response getTipoVehiculo(@PathParam("tipo_vehiculo_id") String id) {
		int id_num;
		try {
			id_num = Integer.parseInt(id);
		}
		catch (NumberFormatException e) {
			return Response.status(Response.Status.BAD_REQUEST).entity("El identificador utilizado ("+id+") no tiene formato de número entero").build();
		}
		if (factoria.getTiposVehiculo().containsKey(id_num)) {
			return Response.status(Response.Status.OK).entity(factoria.getTiposVehiculo().get(id_num)).header("Content-Location", uriInfo.getAbsolutePath()).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).entity("No existe un tipo_vehiculo con el identificador "+id).build();
		}
	}
	
	@POST
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response createTipoVehiculo(TipoVehiculo tv) {
		factoria.addTipoVehiculo(tv);
		return Response.status(Response.Status.CREATED).header("Location", uriInfo.getPath().toString() + "/" + tv.getId()).build();
	}
}
