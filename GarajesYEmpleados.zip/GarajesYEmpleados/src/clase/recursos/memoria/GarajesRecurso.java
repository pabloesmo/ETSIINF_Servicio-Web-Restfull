package clase.recursos.memoria;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.naming.NamingContext;

import clase.datos.*;

@Path("/garajes")
public class GarajesRecurso {

	@Context
	private UriInfo uriInfo;

	private Factoria factoria;
	
	public GarajesRecurso() {
		this.factoria = Factoria.getInstance();
	}
	
	// Listado automático de los garajes no puede hacerse en XML sin hacer una clase que
	// englobe a la lista al ser una colección proviniente de un HashTable.
	// En JSON sí puede generarse un array a partir de una colección
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTiposVehiculo() {
		return Response.status(Response.Status.OK).entity(factoria.getGarajes().values()).header("Content-Location", uriInfo.getAbsolutePath()).build();
	}
	

	@GET
	@Path("{garaje_id}")
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response getTipoVehiculo(@PathParam("garaje_id") String id) {
		int id_num;
		try {
			id_num = Integer.parseInt(id);
		}
		catch (NumberFormatException e) {
			return Response.status(Response.Status.BAD_REQUEST).entity("El identificador utilizado ("+id+") no tiene formato de número entero").build();
		}
		if (factoria.getGarajes().containsKey(id_num)) {
			return Response.status(Response.Status.OK).entity(factoria.getGarajes().get(id_num)).header("Content-Location", uriInfo.getAbsolutePath()).build();
		} else {
			return Response.status(Response.Status.NOT_FOUND).entity("No existe un garaje con el identificador "+id).build();
		}
	}

}
